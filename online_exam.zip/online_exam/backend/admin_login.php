<?php
session_start();
require "../db.php";

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM admin WHERE username=? AND password=SHA2(?,256)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
    $_SESSION['admin'] = $username;
    header("Location: ../admin_dashboard.php");
}else{
    echo "Sai tài khoản hoặc mật khẩu!";
}
?>
