<?php
require "../db.php";

$student_id = $_POST['student_id'];
$password   = $_POST['password'];
$confirm    = $_POST['confirm_password'];

if($password !== $confirm){
    die("Mật khẩu xác nhận không khớp!");
}

// Kiểm tra tồn tại
$sql = "SELECT * FROM student WHERE student_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
if($result->num_rows > 0){
    die("Mã sinh viên đã tồn tại!");
}

// Thêm mới
$sql = "INSERT INTO student (student_id,password) VALUES (?,SHA2(?,256))";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $student_id, $password);
if($stmt->execute()){
    echo "Đăng ký thành công!";
}else{
    echo "Có lỗi xảy ra!";
}
?>
