<?php
session_start();
require "connect/db.php";

if(isset($_SESSION['admin'])){
    header("Location: admin_dashboard.php");
    exit();
}

if(isset($_SESSION['student'])){
    header("Location: student_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cao đẳng Nông nghiệp Nam Bộ</title>
      <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #667eea 100%);
            background-size: 200% 200%;
            animation: gradientShift 8s ease infinite;
            min-height: 100vh;
            color: #333;
            overflow-x: hidden;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Styles */
        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            overflow: hidden;
        }

        .header::before {
            content: '';
            position: absolute;
            top: -100%;
            left: -100%;
            width: 300%;
            height: 300%;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            animation: headerGlow 6s ease-in-out infinite;
        }

        @keyframes headerGlow {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.3; }
            50% { transform: translate(-30%, -30%) scale(1.1); opacity: 0.6; }
        }

        .logo {
            width: 300px;
            height: 300px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            border-radius: 50%;
            margin: 0 auto 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 15px 30px rgba(76, 175, 80, 0.3);
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease;
            animation: logoFloat 4s ease-in-out infinite, logoPulse 2s ease-in-out infinite;
            z-index: 1;
        }

        @keyframes logoFloat {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }

        @keyframes logoPulse {
            0%, 100% { box-shadow: 0 15px 30px rgba(76, 175, 80, 0.3); }
            50% { box-shadow: 0 20px 40px rgba(76, 175, 80, 0.5), 0 0 0 10px rgba(76, 175, 80, 0.1); }
        }

        .logo:hover {
            transform: scale(1.05) translateY(-10px);
            animation-play-state: paused;
        }

        .logo::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.2), transparent);
            transform: rotate(45deg);
            animation: shine 3s infinite;
        }

        @keyframes shine {
            0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
            50% { transform: translateX(100%) translateY(100%) rotate(45deg); }
            100% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
        }

        .logo-text {
            font-size: 48px;
            font-weight: bold;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            z-index: 1;
            position: relative;
        }

        .school-name {
            font-size: 2.2rem;
            font-weight: 700;
            color: #2E7D32;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1.2;
            animation: textGlow 3s ease-in-out infinite;
            position: relative;
            z-index: 1;
        }

        @keyframes textGlow {
            0%, 100% { 
                filter: drop-shadow(0 0 5px rgba(76, 175, 80, 0.3));
            }
            50% { 
                filter: drop-shadow(0 0 15px rgba(76, 175, 80, 0.6));
            }
        }

        .school-subtitle {
            font-size: 1.2rem;
            color: #666;
            font-weight: 400;
            margin-bottom: 20px;
        }

        /* Content Styles */
        .content {
            display: flex;
            gap: 30px;
            justify-content: center;
            align-items: center;
            min-height: 300px;
        }

        /* Floating particles background */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
        }

        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            animation: float 8s infinite linear;
        }

        @keyframes float {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-10px) translateX(100px);
                opacity: 0;
            }
        }

        .button {
            padding: 25px 50px;
            font-size: 1.5rem;
            font-weight: 600;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 200px;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 1px;
            animation: buttonBounce 2s ease-in-out infinite;
        }

        @keyframes buttonBounce {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
        }

        .button:hover {
            animation-play-state: paused;
        }

        .button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s ease;
        }

        .button:hover::before {
            left: 100%;
        }

        .admin-btn {
            background: linear-gradient(135deg, #FF6B6B, #FF5722);
            color: white;
            box-shadow: 0 15px 30px rgba(255, 107, 107, 0.4);
        }

        .admin-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(255, 107, 107, 0.5);
            background: linear-gradient(135deg, #FF5722, #D32F2F);
        }

        .student-btn {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            box-shadow: 0 15px 30px rgba(76, 175, 80, 0.4);
        }

        .student-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(76, 175, 80, 0.5);
            background: linear-gradient(135deg, #2E7D32, #1B5E20);
        }

        /* Icon styles */
        .button-icon {
            margin-right: 15px;
            font-size: 2rem;
            animation: iconSpin 3s ease-in-out infinite;
        }

        @keyframes iconSpin {
            0%, 100% { transform: rotate(0deg); }
            25% { transform: rotate(5deg); }
            75% { transform: rotate(-5deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                padding: 10px;
            }

            .content {
                flex-direction: column;
                gap: 20px;
            }

            .button {
                width: 100%;
                max-width: 300px;
                padding: 20px 40px;
                font-size: 1.3rem;
            }

            .school-name {
                font-size: 2rem;
            }

            .logo {
                width: 250px;
                height: 250px;
            }

            .logo-text {
                font-size: 36px;
            }
        }

        @media (max-width: 480px) {
            .logo {
                width: 200px;
                height: 200px;
            }

            .logo-text {
                font-size: 28px;
            }

            .school-name {
                font-size: 1.5rem;
            }

            .school-subtitle {
                font-size: 1rem;
            }
        }

        /* Popup Styles */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            animation: fadeIn 0.3s ease;
        }

        .popup-overlay.active {
            display: flex;
        }

        .popup {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            width: 90%;
            max-width: 450px;
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
            position: relative;
            animation: popupIn 0.4s ease;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes popupIn {
            from { 
                opacity: 0; 
                transform: translateY(-30px) scale(0.9); 
            }
            to { 
                opacity: 1; 
                transform: translateY(0) scale(1); 
            }
        }

        .popup-close {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            font-size: 2rem;
            cursor: pointer;
            color: #666;
            transition: all 0.3s ease;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }

        .popup-close:hover {
            background: rgba(255, 107, 107, 0.1);
            color: #FF6B6B;
            transform: rotate(90deg);
        }

        .popup-title {
            text-align: center;
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 30px;
            color: #333;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .admin-title {
            background: linear-gradient(135deg, #FF6B6B, #FF5722);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .student-title {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.8);
            transition: all 0.3s ease;
            outline: none;
        }

        .form-input:focus {
            border-color: #4CAF50;
            background: rgba(255, 255, 255, 1);
            box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.1);
        }

        .admin-popup .form-input:focus {
            border-color: #FF6B6B;
            box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.1);
        }

        .form-label {
            position: absolute;
            top: 15px;
            left: 20px;
            color: #666;
            font-size: 1rem;
            pointer-events: none;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
            padding: 0 5px;
        }

        .form-input:focus + .form-label,
        .form-input:not(:placeholder-shown) + .form-label {
            top: -10px;
            font-size: 0.8rem;
            color: #4CAF50;
            font-weight: 600;
        }

        .admin-popup .form-input:focus + .form-label {
            color: #FF6B6B;
        }

        .form-button {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            margin-bottom: 15px;
            position: relative;
            overflow: hidden;
        }

        .login-button {
            background: linear-gradient(135deg, #4CAF50, #2E7D32);
            color: white;
            box-shadow: 0 10px 20px rgba(76, 175, 80, 0.3);
        }

        .admin-popup .login-button {
            background: linear-gradient(135deg, #FF6B6B, #FF5722);
            box-shadow: 0 10px 20px rgba(255, 107, 107, 0.3);
        }

        .login-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 25px rgba(76, 175, 80, 0.4);
        }

        .admin-popup .login-button:hover {
            box-shadow: 0 15px 25px rgba(255, 107, 107, 0.4);
        }

        .register-button {
            background: transparent;
            color: #4CAF50;
            border: 2px solid #4CAF50;
        }

        .admin-popup .register-button {
            color: #FF6B6B;
            border-color: #FF6B6B;
        }

        .register-button:hover {
            background: #4CAF50;
            color: white;
        }

        .admin-popup .register-button:hover {
            background: #FF6B6B;
            color: white;
        }

        .form-toggle {
            text-align: center;
            margin-top: 20px;
            color: #666;
        }

        .form-toggle-link {
            color: #4CAF50;
            text-decoration: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .admin-popup .form-toggle-link {
            color: #FF6B6B;
        }

        .form-toggle-link:hover {
            text-decoration: underline;
        }

        .register-form {
            display: none;
        }

        .register-form.active {
            display: block;
        }

        /* Animation for page load */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header {
            animation: fadeInUp 0.8s ease;
        }

        .content {
            animation: fadeInUp 0.8s ease 0.2s both;
        }
    </style>
</head>
<body>
    <div class="particles" id="particles"></div>
    
    <div class="container">
        <header class="header">
            <div class="logo">
                 <img src="images/logo.jpg" alt="Logo" class="logo-img">
            </div>
            <h1 class="school-name">Cao Đẳng Nông nghiệp Nam Bộ<br>Phân hiệu TP.Hồ Chí Minh</h1>
            <p class="school-subtitle">Đào tạo chất lượng - Phát triển bền vững</p>
        </header>

        <main class="content">
            <a href="#" class="button admin-btn" onclick="handleAdminClick()">
                <span class="button-icon">👨‍💼</span>
                Admin
            </a>
            
            <a href="#" class="button student-btn" onclick="handleStudentClick()">
                <span class="button-icon">🎓</span>
                Sinh viên
            </a>
        </main>
    </div>

    <!-- Admin Login Popup -->
    <div id="adminPopup" class="popup-overlay">
        <div class="popup admin-popup">
            <button class="popup-close" onclick="closePopup('adminPopup')">&times;</button>
            <h2 class="popup-title admin-title">Đăng nhập Admin</h2>
            
         <form id="adminLoginForm" method="post" action="login_register.php">
            <input type="hidden" name="role" value="admin">
            <div class="form-group">
                <input type="text" id="adminUsername" name="username" class="form-input" placeholder=" " required>
                <label for="adminUsername" class="form-label">Tên đăng nhập</label>
            </div>
            <div class="form-group">
                <input type="password" id="adminPassword" name="password" class="form-input" placeholder=" " required>
                <label for="adminPassword" class="form-label">Mật khẩu</label>
            </div>
            <button type="submit" class="form-button login-button">Đăng nhập</button>
        </form>

        </div>
    </div>

    <!-- Student Login/Register Popup -->
   <div id="studentPopup" class="popup-overlay">
    <div class="popup">
        <button class="popup-close" onclick="closePopup('studentPopup')">&times;</button>
        
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h2 class="popup-title student-title">Đăng nhập Sinh viên</h2>
            
            <form method="post" action="login_register.php">
                <input type="hidden" name="role" value="student">
                
                <div class="form-group">
                    <input type="text" id="studentUsername" name="username" class="form-input" placeholder=" " required>
                    <label for="studentUsername" class="form-label">Tên đăng nhập</label>
                </div>
                
                <div class="form-group">
                    <input type="password" id="studentPassword" name="password" class="form-input" placeholder=" " required>
                    <label for="studentPassword" class="form-label">Mật khẩu</label>
                </div>
                
                <button type="submit" class="form-button login-button">Đăng nhập</button>
            </form>

            <div class="form-toggle">
                Chưa có tài khoản? 
                <span class="form-toggle-link" onclick="toggleForm()">Đăng ký ngay</span>
            </div>
        </div>

        <!-- Register Form -->
        <div id="registerForm" class="register-form">
            <h2 class="popup-title student-title">Đăng ký Sinh viên</h2>
            <form method="post" action="login_register.php">
                <input type="hidden" name="role" value="student_register">

                <div class="form-group">
                    <input type="text" id="regUsername" name="username" class="form-input" placeholder=" " required>
                    <label for="regUsername" class="form-label">Tên đăng nhập</label>
                </div>

                <div class="form-group">
                    <input type="text" id="regStudentId" name="student_id" class="form-input" placeholder=" " required>
                    <label for="regStudentId" class="form-label">Mã sinh viên</label>
                </div>

                <div class="form-group">
                    <input type="password" id="regPassword" name="password" class="form-input" placeholder=" " required>
                    <label for="regPassword" class="form-label">Mật khẩu</label>
                </div>

                <div class="form-group">
                    <input type="password" id="regConfirmPassword" name="confirm_password" class="form-input" placeholder=" " required>
                    <label for="regConfirmPassword" class="form-label">Nhập lại mật khẩu</label>
                </div>

                <div class="form-group">
                    <input type="text" id="regFullName" name="full_name" class="form-input" placeholder=" " required>
                    <label for="regFullName" class="form-label">Họ và tên</label>
                </div>

                <div class="form-group">
                    <input type="email" id="regEmail" name="email" class="form-input" placeholder=" " required>
                    <label for="regEmail" class="form-label">Email</label>
                </div>

                <!-- Ngày sinh -->
                <div class="form-group">
                    <input type="date" id="regBirthDate" name="birth_date" class="form-input" placeholder=" " required>
                    <label for="regBirthDate" class="form-label">Ngày sinh</label>
                </div>

                <!-- Nơi sinh -->
                <div class="form-group">
                    <input type="text" id="regBirthPlace" name="birth_place" class="form-input" placeholder=" " required>
                    <label for="regBirthPlace" class="form-label">Nơi sinh</label>
                </div>

                <button type="submit" class="form-button login-button">Đăng ký</button>
            </form>

            <div class="form-toggle">
                Đã có tài khoản? 
                <span class="form-toggle-link" onclick="toggleForm()">Đăng nhập</span>
            </div>
        </div>
<script>
function handleStudentLogin(event) {
    event.preventDefault();
    const studentId = document.getElementById('studentUsername').value;
    const password = document.getElementById('studentPassword').value;

    if(studentId && password){
        alert('Đăng nhập Sinh viên thành công!');
        closePopup('studentPopup');
        // window.location.href = 'student-dashboard.html';
    } else {
        alert('Vui lòng nhập đầy đủ thông tin!');
    }
}

function handleStudentRegister(event){
    event.preventDefault();
    const studentId = document.getElementById('regStudentId').value;
    const password = document.getElementById('regPassword').value;

    if(studentId && password){
        alert('Đăng ký thành công! Vui lòng đăng nhập.');
        toggleForm();
        document.getElementById('regStudentId').value = '';
        document.getElementById('regPassword').value = '';
    } else {
        alert('Vui lòng nhập đầy đủ thông tin!');
    }
}
</script>



    <script>
        /* --- Giữ nguyên JS popup, particles, ripple, toggle form ... --- */
        function handleAdminClick() { openPopup('adminPopup'); }
        function handleStudentClick() { openPopup('studentPopup'); }
        function openPopup(popupId) { const popup=document.getElementById(popupId); popup.classList.add('active'); document.body.style.overflow='hidden'; }
        function closePopup(popupId) { const popup=document.getElementById(popupId); popup.classList.remove('active'); document.body.style.overflow='auto'; if(popupId==='studentPopup'){document.getElementById('loginForm').style.display='block'; document.getElementById('registerForm').classList.remove('active');} }
        function toggleForm() { const l=document.getElementById('loginForm'); const r=document.getElementById('registerForm'); if(l.style.display!=='none'){l.style.display='none'; r.classList.add('active');}else{l.style.display='block'; r.classList.remove('active');} }
        
        // --- Floating particles ---
        document.addEventListener('DOMContentLoaded',function(){createParticles();});
        function createParticles(){ const container=document.getElementById('particles'); for(let i=0;i<50;i++){const p=document.createElement('div');p.className='particle';p.style.left=Math.random()*100+'%';p.style.animationDelay=Math.random()*8+'s';p.style.animationDuration=(Math.random()*3+5)+'s';const s=Math.random()*4+2;p.style.width=s+'px';p.style.height=s+'px';container.appendChild(p);}}

        // --- Close popup when click outside ---
        document.addEventListener('click',function(event){document.querySelectorAll('.popup-overlay').forEach(p=>{if(event.target===p){closePopup(p.id);}});});
        document.addEventListener('keydown',function(e){if(e.key==='Escape'){const active=document.querySelector('.popup-overlay.active'); if(active){closePopup(active.id);}}});

        // --- Ripple effect ---
        document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.button').forEach(btn=>{btn.addEventListener('click',function(e){const ripple=document.createElement('span'); const rect=this.getBoundingClientRect(); const size=Math.max(rect.width,rect.height); const x=e.clientX-rect.left-size/2; const y=e.clientY-rect.top-size/2; ripple.style.cssText=`position:absolute;border-radius:50%;background:rgba(255,255,255,0.5);transform:scale(0);animation:ripple 0.6s linear;width:${size}px;height:${size}px;left:${x}px;top:${y}px`;this.appendChild(ripple);setTimeout(()=>{ripple.remove();},600);});});});

        const style = document.createElement('style');
        style.textContent=`@keyframes ripple{to{transform:scale(2);opacity:0;}}`;
        document.head.appendChild(style);
    </script>
</body>
</html>
