<?php
session_start();
require "connect/db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['role'];

    // --- ADMIN LOGIN ---
    if ($role === 'admin') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT * FROM admins WHERE username=?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $admin = $res->fetch_assoc();
            if (hash('sha256', $password) === $admin['password']) {
                $_SESSION['admin'] = $admin['id'];
                header("Location: admin/admin_dashboard.php?success=Đăng nhập thành công");
                exit();
            } else {
                header("Location: index.php?error=Sai mật khẩu admin");
                exit();
            }
        } else {
            header("Location: index.php?error=Tài khoản admin không tồn tại");
            exit();
        }
    }
   // --- STUDENT LOGIN BẰNG USERNAME ---
    elseif ($role === 'student') {
        $username = $_POST['username'];  // sửa từ student_id => username
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT * FROM students WHERE username=?");
        if (!$stmt) die("Prepare failed: " . $conn->error);

        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows === 1) {
            $student = $res->fetch_assoc();
            if (password_verify($password, $student['password'])) {
                $_SESSION['student'] = $student['id'];
                header("Location: student/student_dashboard.php?success=Đăng nhập thành công");
                exit();
            } else {
                header("Location: index.php?error=Sai mật khẩu sinh viên");
                exit();
            }
        } else {
            header("Location: index.php?error=Tài khoản sinh viên không tồn tại");
            exit();
        }
    }
    // --- STUDENT REGISTER ---
    elseif ($role === 'student_register') {
        $username = $_POST['username'];
        $student_id = $_POST['student_id'];
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $birth_date = $_POST['birth_date'];   // yyyy-mm-dd
        $birth_place = $_POST['birth_place'];

        // Kiểm tra mật khẩu trùng khớp
        if ($password !== $confirm_password) {
            header("Location: index.php?error=Mật khẩu không trùng khớp");
            exit();
        }

        // Kiểm tra username hoặc student_id đã tồn tại
        $stmt = $conn->prepare("SELECT * FROM students WHERE username=? OR student_id=?");
        $stmt->bind_param("ss", $username, $student_id);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res->num_rows > 0) {
            header("Location: index.php?error=Tài khoản đã tồn tại");
            exit();
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO students(username, student_id, password, full_name, email, birth_date, birth_place) 
                                    VALUES(?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssss", $username, $student_id, $hash, $full_name, $email, $birth_date, $birth_place);
            $stmt->execute();
            header("Location: index.php?success=Đăng ký thành công, vui lòng đăng nhập");
            exit();
        }
    }

}
?>
