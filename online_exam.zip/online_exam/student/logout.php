<?php
session_start();

// Xóa session sinh viên
unset($_SESSION['student']);
session_destroy();

// Quay về trang index
header("Location: ../index.php");
exit();
?>
