<?php
session_start();
require "../connect/db.php";

// Kiểm tra student login
if (!isset($_SESSION['student'])) {
    header("Location: ../index.php?error=Vui lòng đăng nhập");
    exit();
}

// Lấy thông tin sinh viên
$student_id = $_SESSION['student'];
$stmt = $conn->prepare("SELECT username, student_id, full_name, email FROM students WHERE id=?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows !== 1) {
    // Nếu không tìm thấy sinh viên → logout và về index
    session_unset();
    session_destroy();
    header("Location: ../index.php?error=Không tìm thấy thông tin sinh viên");
    exit();
}

$student = $res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trang Sinh viên</title>
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: Arial, sans-serif; background: #f0f2f5; }

    /* Navbar */
    .navbar {
        width: 100%;
        background: #4CAF50;
        color: white;
        padding: 15px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    .navbar .brand { font-size: 1.5rem; font-weight: bold; }
    .navbar .user-info { font-size: 1rem; }
    .navbar .logout-btn, .navbar .edit-btn {
        margin-left: 10px;
        padding: 8px 15px;
        border-radius: 8px;
        color: white;
        text-decoration: none;
        transition: 0.3s;
    }
    .navbar .logout-btn { background: #FF6B6B; }
    .navbar .logout-btn:hover { background: #FF3B3B; }
    .navbar .edit-btn { background: #FF9800; }
    .navbar .edit-btn:hover { background: #FFB74D; }

    /* Content */
    .content {
        max-width: 1200px;
        margin: 80px auto 0 auto; /* cách navbar */
        padding: 20px;
    }
    .card {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    .card h2 { color: #333; margin-bottom: 15px; }
    .card p { font-size: 1.1rem; margin: 10px 0; }
</style>
</head>
<body>

    <div class="navbar">
        <div class="brand">Trang Sinh viên</div>
        <div class="user-info">
            <?php echo htmlspecialchars($student['full_name']); ?> | Mã SV: <?php echo htmlspecialchars($student['student_id']); ?>
            <a href="edit_student.php" class="edit-btn">Chỉnh sửa thông tin</a>
            <a href="logout.php" class="logout-btn">Đăng xuất</a>
        </div>
    </div>

    <div class="content">
        <div class="card">
            <h2>Thông tin sinh viên</h2>
            <p><strong>Họ và tên:</strong> <?php echo htmlspecialchars($student['full_name']); ?></p>
            <p><strong>Mã sinh viên:</strong> <?php echo htmlspecialchars($student['student_id']); ?></p>
        </div>
    </div>

</body>
</html>
