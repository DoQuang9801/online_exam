<?php
session_start();
require "../connect/db.php";

// Kiểm tra đăng nhập
if (!isset($_SESSION['student'])) {
    header("Location: ../index.php?error=Vui lòng đăng nhập");
    exit();
}

$student_id = $_SESSION['student'];

// Lấy thông tin sinh viên
$stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$res = $stmt->get_result();
$student = $res->fetch_assoc();

if (!$student) {
    die("Không tìm thấy thông tin sinh viên.");
}

// Xử lý cập nhật thông tin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username    = isset($_POST['username']) ? $_POST['username'] : '';
    $full_name   = isset($_POST['full_name']) ? $_POST['full_name'] : '';
    $email       = isset($_POST['email']) ? $_POST['email'] : '';
    $birth_date  = isset($_POST['birth_date']) ? $_POST['birth_date'] : '';
    $birth_place = isset($_POST['birth_place']) ? $_POST['birth_place'] : '';
    $password    = isset($_POST['password']) ? $_POST['password'] : '';

    if (!empty($password)) {
        $hash = hash('sha256', $password); // SHA-256
        $stmt = $conn->prepare("UPDATE students SET username=?, full_name=?, email=?, birth_date=?, birth_place=?, password=? WHERE id=?");
        $stmt->bind_param("ssssssi", $username, $full_name, $email, $birth_date, $birth_place, $hash, $student_id);
    } else {
        $stmt = $conn->prepare("UPDATE students SET username=?, full_name=?, email=?, birth_date=?, birth_place=? WHERE id=?");
        $stmt->bind_param("sssssi", $username, $full_name, $email, $birth_date, $birth_place, $student_id);
    }
    $stmt->execute();
    header("Location: edit_student.php?success=Thông tin đã được cập nhật");
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cập nhật thông tin cá nhân</title>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body { 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        position: relative;
    }

    /* Floating background particles */
    body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: 
            radial-gradient(circle at 25% 75%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 75% 25%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 50% 50%, rgba(120, 219, 255, 0.3) 0%, transparent 50%);
        animation: float 15s ease-in-out infinite;
        z-index: -1;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        33% { transform: translateY(-20px) rotate(120deg); }
        66% { transform: translateY(10px) rotate(240deg); }
    }

    .container { 
        max-width: 500px; 
        width: 100%;
        padding: 40px;
        background: rgba(255, 255, 255, 0.95);
        border-radius: 25px;
        box-shadow: 
            0 25px 50px rgba(0,0,0,0.15),
            inset 0 1px 0 rgba(255,255,255,0.6);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,0.3);
        animation: slideInUp 0.8s ease;
        position: relative;
        overflow: hidden;
    }

    /* Subtle gradient overlay */
    .container::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(90deg, #667eea, #764ba2, #667eea);
        background-size: 200% 100%;
        animation: shimmer 3s linear infinite;
    }

    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }

    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(50px) scale(0.9);
        }
        to {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
    }

    h1 { 
        color: #2c3e50;
        margin-bottom: 30px;
        text-align: center;
        font-size: 2.2rem;
        font-weight: 700;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        animation: fadeInDown 1s ease;
    }

    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .success-message {
        background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
        color: white;
        padding: 15px 20px;
        border-radius: 12px;
        margin-bottom: 25px;
        font-weight: 500;
        text-align: center;
        box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);
        animation: slideInLeft 0.6s ease;
    }

    @keyframes slideInLeft {
        from {
            opacity: 0;
            transform: translateX(-50px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    form {
        animation: fadeIn 1.2s ease;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    form input { 
        width: 100%; 
        padding: 16px 20px;
        margin: 12px 0;
        border: 2px solid #e1e8ed;
        border-radius: 15px;
        font-size: 16px;
        font-family: inherit;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.8);
        position: relative;
    }

    form input:focus {
        outline: none;
        border-color: #667eea;
        background: rgba(255,255,255,1);
        box-shadow: 
            0 0 25px rgba(102, 126, 234, 0.3),
            inset 0 1px 0 rgba(255,255,255,0.8);
        transform: translateY(-2px);
    }

    form input:disabled {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        color: #6c757d;
        cursor: not-allowed;
        border-color: #dee2e6;
    }

    form input::placeholder {
        color: #999;
        font-style: italic;
    }

    form button { 
        width: 100%;
        padding: 16px 20px;
        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
        color: white;
        border: none;
        border-radius: 15px;
        cursor: pointer;
        font-size: 16px;
        font-weight: 600;
        font-family: inherit;
        transition: all 0.3s ease;
        margin-top: 10px;
        box-shadow: 0 6px 20px rgba(52, 152, 219, 0.4);
        position: relative;
        overflow: hidden;
    }

    form button::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.6s ease;
    }

    form button:hover {
        background: linear-gradient(135deg, #2980b9 0%, #1f5f8b 100%);
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(52, 152, 219, 0.6);
    }

    form button:hover::before {
        left: 100%;
    }

    form button:active {
        transform: translateY(-1px);
    }

    a.logout { 
        display: inline-block;
        width: 100%;
        text-align: center;
        margin-top: 20px;
        padding: 14px 20px;
        background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        color: white;
        border-radius: 15px;
        text-decoration: none;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s ease;
        box-shadow: 0 6px 20px rgba(231, 76, 60, 0.4);
        position: relative;
        overflow: hidden;
    }

    a.logout::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.6s ease;
    }

    a.logout:hover {
        background: linear-gradient(135deg, #c0392b 0%, #a93226 100%);
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(231, 76, 60, 0.6);
    }

    a.logout:hover::before {
        left: 100%;
    }

    a.logout:active {
        transform: translateY(-1px);
    }

    /* Profile icon animation */
    h1::before {
        content: '👤';
        margin-right: 10px;
        font-size: 2rem;
        animation: bounce 2s infinite;
    }

    @keyframes bounce {
        0%, 20%, 50%, 80%, 100% {
            transform: translateY(0);
        }
        40% {
            transform: translateY(-10px);
        }
        60% {
            transform: translateY(-5px);
        }
    }

    /* Input focus glow effect */
    form input:focus {
        animation: glow 2s ease-in-out infinite alternate;
    }

    @keyframes glow {
        from {
            box-shadow: 0 0 25px rgba(102, 126, 234, 0.3);
        }
        to {
            box-shadow: 0 0 35px rgba(102, 126, 234, 0.5);
        }
    }

    /* Responsive design */
    @media (max-width: 600px) {
        .container {
            padding: 30px 25px;
            margin: 10px;
        }

        h1 {
            font-size: 1.8rem;
        }

        form input,
        form button,
        a.logout {
            padding: 14px 16px;
            font-size: 15px;
        }
    }

    /* Scrollbar styling */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(255,255,255,0.1);
    }
    
    ::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.3);
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: rgba(255,255,255,0.5);
    }
</style>
</head>
<body>
<div class="container">
    <h1>Cập nhật thông tin cá nhân</h1>

    <?php if (isset($_GET['success'])): ?>
        <div class="success-message">
            ✅ <?php echo htmlspecialchars($_GET['success']); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="">
        <input type="text" name="username" placeholder="🔑 Tên đăng nhập" value="<?php echo htmlspecialchars($student['username']); ?>" required>
        <input type="text" name="student_id" value="🎓 <?php echo htmlspecialchars($student['student_id']); ?>" disabled>
        <input type="text" name="full_name" placeholder="👤 Họ và tên" value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
        <input type="email" name="email" placeholder="📧 Email" value="<?php echo htmlspecialchars($student['email']); ?>" required>
        <input type="date" name="birth_date" placeholder="📅 Ngày sinh" value="<?php echo htmlspecialchars($student['birth_date']); ?>" required>
        <input type="text" name="birth_place" placeholder="🌍 Nơi sinh" value="<?php echo htmlspecialchars($student['birth_place']); ?>" required>
        <input type="password" name="password" placeholder="🔒 Mật khẩu (để trống nếu không đổi)">
        <button type="submit">💾 Cập nhật thông tin</button>
    </form>

    <a href="student_dashboard.php" class="logout">🏠 Quay lại Dashboard</a>
</div>
</body>
</html>
