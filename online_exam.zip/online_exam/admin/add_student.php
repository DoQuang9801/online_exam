<?php
session_start();
require "../connect/db.php";

// Kiểm tra admin login
if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php?error=Vui lòng đăng nhập admin");
    exit();
}

// --- Xử lý Xóa ---
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $stmt = $conn->prepare("DELETE FROM students WHERE id=?");
    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    header("Location: add_student.php?success=Đã xóa sinh viên");
    exit();
}

// --- Xử lý Thêm/Sửa ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $student_id = isset($_POST['student_id']) ? $_POST['student_id'] : '';
    $full_name = isset($_POST['full_name']) ? $_POST['full_name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $birth_date = isset($_POST['birth_date']) ? $_POST['birth_date'] : '';
    $birth_place = isset($_POST['birth_place']) ? $_POST['birth_place'] : '';

    if ($id != '') {
        // Sửa sinh viên
        if (!empty($password)) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE students SET username=?, student_id=?, full_name=?, email=?, password=?, birth_date=?, birth_place=? WHERE id=?");
            if ($stmt) {
                $stmt->bind_param("sssssssi", $username, $student_id, $full_name, $email, $hash, $birth_date, $birth_place, $id);
                $stmt->execute();
            }
        } else {
            $stmt = $conn->prepare("UPDATE students SET username=?, student_id=?, full_name=?, email=?, birth_date=?, birth_place=? WHERE id=?");
            if ($stmt) {
                $stmt->bind_param("ssssssi", $username, $student_id, $full_name, $email, $birth_date, $birth_place, $id);
                $stmt->execute();
            }
        }
        header("Location: add_student.php?success=Đã cập nhật sinh viên");
        exit();
    } else {
        // Thêm mới
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO students(username, student_id, full_name, email, password, birth_date, birth_place) VALUES(?,?,?,?,?,?,?)");
        if ($stmt) {
            $stmt->bind_param("sssssss", $username, $student_id, $full_name, $email, $hash, $birth_date, $birth_place);
            $stmt->execute();
        }
        header("Location: add_student.php?success=Đã thêm sinh viên mới");
        exit();
    }
}

// Lấy danh sách sinh viên
$result = $conn->query("SELECT * FROM students ORDER BY id DESC");

// --- Kiểm tra nếu sửa ---
$editStudent = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    $stmt = $conn->prepare("SELECT * FROM students WHERE id=?");
    if ($stmt) {
        $stmt->bind_param("i", $edit_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res->num_rows > 0) {
            $editStudent = $res->fetch_assoc();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quản lý Sinh viên</title>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body { 
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        padding: 20px 0;
        position: relative;
    }

    /* Floating background effect */
    body::before {
        content: '';
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: 
            radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.3) 0%, transparent 50%);
        animation: float 20s ease-in-out infinite;
        z-index: -1;
    }

    @keyframes float {
        0%, 100% { transform: translateY(0px) rotate(0deg); }
        50% { transform: translateY(-20px) rotate(180deg); }
    }

    .container { 
        max-width: 1200px; 
        margin: 0 auto; 
        padding: 20px; 
        position: relative;
        z-index: 1;
    }

    h1 { 
        color: white; 
        margin-bottom: 30px; 
        font-size: 2.5rem;
        text-align: center;
        text-shadow: 0 4px 8px rgba(0,0,0,0.3);
        animation: fadeInDown 0.8s ease;
    }

    @keyframes fadeInDown {
        from {
            opacity: 0;
            transform: translateY(-30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .back-btn {
        display: inline-block;
        margin-bottom: 20px;
        padding: 12px 24px;
        background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        color: white;
        text-decoration: none;
        border-radius: 25px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
        position: relative;
        overflow: hidden;
    }

    .back-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s ease;
    }

    .back-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(231, 76, 60, 0.6);
    }

    .back-btn:hover::before {
        left: 100%;
    }

    form { 
        background: rgba(255, 255, 255, 0.95);
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        margin-bottom: 30px;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.3);
        animation: fadeInUp 0.8s ease;
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    form input { 
        width: 100%; 
        padding: 15px; 
        margin: 10px 0; 
        border: 2px solid #e1e8ed; 
        border-radius: 12px;
        font-size: 16px;
        transition: all 0.3s ease;
        background: rgba(255,255,255,0.9);
    }

    form input:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 20px rgba(102, 126, 234, 0.3);
        transform: translateY(-2px);
    }

    form button { 
        padding: 15px 30px; 
        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
        color: white; 
        border: none; 
        border-radius: 12px; 
        cursor: pointer;
        font-size: 16px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(52, 152, 219, 0.4);
        position: relative;
        overflow: hidden;
    }

    form button::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s ease;
    }

    form button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(52, 152, 219, 0.6);
    }

    form button:hover::before {
        left: 100%;
    }

    table { 
        width: 100%; 
        border-collapse: collapse; 
        background: rgba(255, 255, 255, 0.95); 
        border-radius: 20px; 
        overflow: hidden; 
        box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255,255,255,0.3);
        animation: fadeInUp 1s ease;
    }

    th, td { 
        padding: 18px 20px; 
        text-align: left;
        font-size: 14px;
    }

    th { 
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white; 
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: none;
    }

    td {
        border-bottom: 1px solid rgba(0,0,0,0.1);
        color: #2c3e50;
    }

    tr:hover { 
        background: rgba(102, 126, 234, 0.1);
        transform: scale(1.01);
        transition: all 0.3s ease;
    }

    .btn { 
        padding: 8px 16px; 
        border-radius: 20px; 
        text-decoration: none; 
        color: white; 
        margin-right: 8px;
        font-weight: 500;
        transition: all 0.3s ease;
        display: inline-block;
        position: relative;
        overflow: hidden;
        font-size: 13px;
    }

    .btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s ease;
    }

    .edit { 
        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
        box-shadow: 0 4px 15px rgba(52, 152, 219, 0.4);
    }

    .delete { 
        background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        box-shadow: 0 4px 15px rgba(231, 76, 60, 0.4);
    }

    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.3);
    }

    .btn:hover::before {
        left: 100%;
    }

    /* Success/Error Messages */
    .message {
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 12px;
        font-weight: 500;
        animation: slideIn 0.5s ease;
    }

    .success {
        background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%);
        color: white;
    }

    .error {
        background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        color: white;
    }

    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(-100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    /* Responsive */
    @media (max-width: 768px) {
        .container {
            padding: 15px;
        }
        
        h1 {
            font-size: 2rem;
        }
        
        form {
            padding: 20px;
        }
        
        table {
            font-size: 12px;
        }
        
        th, td {
            padding: 12px 8px;
        }
        
        .btn {
            padding: 6px 12px;
            font-size: 11px;
            margin: 2px;
        }
    }

    /* Scrollbar styling */
    ::-webkit-scrollbar {
        width: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: rgba(255,255,255,0.1);
    }
    
    ::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.3);
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: rgba(255,255,255,0.5);
    }
</style>
</head>
<body>
<div class="container">
       <h1>👩‍🎓 Quản lý Sinh viên</h1>
    <a href="admin_dashboard.php" class="back-btn">🏠 Quay về Dashboard</a>

    <?php if(isset($_GET['success'])): ?>
        <div class="message success">✅ <?php echo htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>

    <?php if(isset($_GET['error'])): ?>
        <div class="message error">❌ <?php echo htmlspecialchars($_GET['error']); ?></div>
    <?php endif; ?>

    <!-- Form thêm/sửa -->
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo isset($editStudent['id']) ? $editStudent['id'] : ''; ?>">
        <input type="text" name="username" placeholder="🔑 Tên đăng nhập" value="<?php echo isset($editStudent['username']) ? $editStudent['username'] : ''; ?>" required>
        <input type="text" name="student_id" placeholder="🎓 Mã sinh viên" value="<?php echo isset($editStudent['student_id']) ? $editStudent['student_id'] : ''; ?>" required>
        <input type="text" name="full_name" placeholder="👤 Họ và tên" value="<?php echo isset($editStudent['full_name']) ? $editStudent['full_name'] : ''; ?>" required>
        <input type="email" name="email" placeholder="📧 Email" value="<?php echo isset($editStudent['email']) ? $editStudent['email'] : ''; ?>" required>
        <input type="date" name="birth_date" value="<?php echo isset($editStudent['birth_date']) ? $editStudent['birth_date'] : ''; ?>" required>
        <input type="text" name="birth_place" placeholder="🌍 Nơi sinh" value="<?php echo isset($editStudent['birth_place']) ? $editStudent['birth_place'] : ''; ?>" required>
        <input type="password" name="password" placeholder="🔒 Mật khẩu <?php echo isset($editStudent) ? '(để trống nếu không đổi)' : ''; ?>" <?php echo isset($editStudent) ? '' : 'required'; ?>>
        <button type="submit">
            <?php echo isset($editStudent) ? '✏️ Cập nhật sinh viên' : '➕ Thêm sinh viên mới'; ?>
        </button>
    </form>

    <!-- Bảng danh sách -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Tên đăng nhập</th>
                <th>Mã sinh viên</th>
                <th>Họ và tên</th>
                <th>Email</th>
                <th>Ngày sinh</th>
                <th>Nơi sinh</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['birth_date']); ?></td>
                <td><?php echo htmlspecialchars($row['birth_place']); ?></td>
                <td>
                    <a href="?edit_id=<?php echo $row['id']; ?>" class="btn edit">✏️ Sửa</a>
                    <a href="?delete_id=<?php echo $row['id']; ?>" class="btn delete" onclick="return confirm('⚠️ Bạn có chắc muốn xóa sinh viên này?')">🗑️ Xóa</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>