<?php
session_start();
require "../connect/db.php"; // chỉnh đường dẫn theo server của bạn

// Kiểm tra admin
if(!isset($_SESSION['admin'])){
    header("Location: ../index.php?error=Vui lòng đăng nhập admin");
    exit();
}

// ================== XỬ LÝ MÔN HỌC ==================
if(isset($_POST['add_subject'])){
    $name = trim(isset($_POST['subject_name']) ? $_POST['subject_name'] : '');
    if($name != ''){
        $stmt = $conn->prepare("INSERT INTO subjects(name) VALUES(?)");
        if($stmt){
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $stmt->close();
        }
    }
    header("Location: manage_questions.php");
    exit();
}

if(isset($_GET['delete_subject'])){
    $id = (int)$_GET['delete_subject'];
    $stmt = $conn->prepare("DELETE FROM subjects WHERE id=?");
    if($stmt){
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: manage_questions.php");
    exit();
}

// ================== XỬ LÝ CÂU HỎI ==================
if(isset($_POST['add_question'])){
    $subject_id = (int)$_POST['subject_id'];
    $question = isset($_POST['question']) ? $_POST['question'] : '';
    $a = isset($_POST['option_a']) ? $_POST['option_a'] : '';
    $b = isset($_POST['option_b']) ? $_POST['option_b'] : '';
    $c = isset($_POST['option_c']) ? $_POST['option_c'] : '';
    $d = isset($_POST['option_d']) ? $_POST['option_d'] : '';
    $correct = isset($_POST['correct_answer']) ? $_POST['correct_answer'] : '';

    if($question != '' && $a != '' && $b != '' && $c != '' && $d != '' && $correct != ''){
        $stmt = $conn->prepare("INSERT INTO questions(subject_id, question, option_a, option_b, option_c, option_d, correct_answer) VALUES (?,?,?,?,?,?,?)");
        if($stmt){
            $stmt->bind_param("issssss",$subject_id,$question,$a,$b,$c,$d,$correct);
            $stmt->execute();
            $stmt->close();
        }
    }
    header("Location: manage_questions.php?subject_id=$subject_id");
    exit();
}

if(isset($_POST['update_question'])){
    $id = (int)$_POST['id'];
    $subject_id = (int)$_POST['subject_id'];
    $question = isset($_POST['question']) ? $_POST['question'] : '';
    $a = isset($_POST['option_a']) ? $_POST['option_a'] : '';
    $b = isset($_POST['option_b']) ? $_POST['option_b'] : '';
    $c = isset($_POST['option_c']) ? $_POST['option_c'] : '';
    $d = isset($_POST['option_d']) ? $_POST['option_d'] : '';
    $correct = isset($_POST['correct_answer']) ? $_POST['correct_answer'] : '';

    if($question != '' && $a != '' && $b != '' && $c != '' && $d != '' && $correct != ''){
        $stmt = $conn->prepare("UPDATE questions SET question=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_answer=? WHERE id=?");
        if($stmt){
            $stmt->bind_param("ssssssi",$question,$a,$b,$c,$d,$correct,$id);
            $stmt->execute();
            $stmt->close();
        }
    }
    header("Location: manage_questions.php?subject_id=$subject_id");
    exit();
}

if(isset($_GET['delete_question'])){
    $id = (int)$_GET['delete_question'];
    $subject_id = (int)$_GET['subject_id'];
    $stmt = $conn->prepare("DELETE FROM questions WHERE id=?");
    if($stmt){
        $stmt->bind_param("i",$id);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: manage_questions.php?subject_id=$subject_id");
    exit();
}

// ================== LẤY DỮ LIỆU ==================
$subjects = $conn->query("SELECT * FROM subjects ORDER BY id DESC");
$questions = array();
$current_subject = null;

if(isset($_GET['subject_id'])){
    $subject_id = (int)$_GET['subject_id'];

    $stmt = $conn->prepare("SELECT * FROM questions WHERE subject_id=? ORDER BY id DESC");
    if($stmt){
        $stmt->bind_param("i",$subject_id);
        $stmt->execute();
        $questions = $stmt->get_result();
    }

    $stmt2 = $conn->prepare("SELECT * FROM subjects WHERE id=?");
    if($stmt2){
        $stmt2->bind_param("i",$subject_id);
        $stmt2->execute();
        $current_subject = $stmt2->get_result()->fetch_assoc();
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quản lý Môn học & Câu hỏi</title>
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
}

.header {
    text-align: center;
    color: white;
    margin-bottom: 30px;
    
}
.header a {
    text-decoration: none;
    color:red;
}

.header h1 {
    font-size: 2.5rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    margin-bottom: 10px;
}

.card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    margin: 10px 0;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    overflow: hidden;
    transition: all 0.3s ease;
}

.card-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 15px 25px;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: all 0.3s ease;
}

.card-header:hover {
    background: linear-gradient(135deg, #5a67d8, #6b46c1);
}

.card-content {
    padding: 25px;
    display: none;
}

.card.active .card-content {
    display: block;
}

.card-title {
    font-size: 1.2rem;
    font-weight: 600;
    margin: 0;
}

.expand-icon {
    transition: transform 0.3s ease;
    font-size: 1.2rem;
}

.card.active .expand-icon {
    transform: rotate(180deg);
}

.section-title {
    color: #5a5a5a;
    margin-bottom: 20px;
    font-size: 1.1rem;
    font-weight: 600;
}

.form-group {
    margin-bottom: 20px;
}

.form-control {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e6ed;
    border-radius: 8px;
    font-size: 14px;
    transition: all 0.3s ease;
    background: white;
}

.form-control:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

textarea.form-control {
    resize: vertical;
    min-height: 80px;
}

.btn {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}

.btn-primary {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(40, 167, 69, 0.4);
}

.btn-danger {
    background: linear-gradient(135deg, #dc3545, #e74c3c);
    color: white;
    box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
    font-size: 12px;
    padding: 8px 16px;
}

.btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(220, 53, 69, 0.4);
}

.btn-toggle {
    background: linear-gradient(135deg, #6c757d, #5a6268);
    color: white;
    font-size: 12px;
    padding: 8px 16px;
    margin-left: 15px;
}

.btn-toggle:hover {
    transform: translateY(-1px);
}

.table-container {
    overflow-x: auto;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 12px;
    overflow: hidden;
}

th {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 15px 12px;
    text-align: left;
    font-weight: 600;
    font-size: 14px;
}

td {
    padding: 15px 12px;
    border-bottom: 1px solid #e9ecef;
    vertical-align: top;
}

tr:hover {
    background: rgba(102, 126, 234, 0.05);
}

.subject-link {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.subject-link:hover {
    color: #764ba2;
    text-decoration: underline;
}

.question-content {
    max-width: 300px;
    word-wrap: break-word;
}

.options {
    font-size: 13px;
    line-height: 1.6;
}

.correct-answer {
    background: linear-gradient(135deg, #28a745, #20c997);
    color: white;
    padding: 4px 8px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 12px;
}

.form-inline {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-bottom: 0;
}

.edit-form {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin: 10px 0;
}

.edit-form .form-control {
    margin-bottom: 8px;
}

.question-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
    min-width: 200px;
}

@media (max-width: 768px) {
    .container {
        padding: 10px;
    }
    
    .header h1 {
        font-size: 2rem;
    }
    
    .card {
        padding: 15px;
        margin: 10px 0;
    }
    
    .form-inline {
        flex-direction: column;
        align-items: stretch;
    }
    
    .btn-toggle {
        margin-left: 0;
        margin-top: 10px;
    }
    
    .table-container {
        font-size: 14px;
    }
    
    th, td {
        padding: 10px 8px;
    }
}

.alert {
    padding: 12px 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    border: 1px solid transparent;
}

.alert-info {
    background-color: #d1ecf1;
    border-color: #bee5eb;
    color: #0c5460;
}
</style>
<script>
function toggleCard(cardId) {
    const card = document.getElementById(cardId);
    const allCards = document.querySelectorAll('.card');
    
    // Đóng tất cả cards khác
    allCards.forEach(c => {
        if (c.id !== cardId) {
            c.classList.remove('active');
        }
    });
    
    // Toggle card hiện tại
    card.classList.toggle('active');
}

function toggleTable(){
    var table = document.getElementById('questionTable');
    var btn = event.target;
    if(table.style.display==="none"){
        table.style.display="table";
        btn.textContent = "Thu gọn";
    }
    else{
        table.style.display="none";
        btn.textContent = "Mở rộng";
    }
}
</script>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>🎓 Quản lý Môn học & Câu hỏi</h1>
        <p>Hệ thống quản lý câu hỏi trắc nghiệm</p>
        <a href="admin_dashboard.php">Đăng Xuất</a>
    </div>

    <!-- Quản lý môn học -->
    <div class="card" id="addSubjectCard">
        <div class="card-header" onclick="toggleCard('addSubjectCard')">
            <h2 class="card-title">➕ Thêm môn học mới</h2>
            <span class="expand-icon">▼</span>
        </div>
        <div class="card-content">
            <form method="post" class="form-inline">
                <input type="text" name="subject_name" placeholder="Nhập tên môn học..." required class="form-control" style="flex: 1;">
                <button type="submit" name="add_subject" class="btn btn-primary">Thêm môn</button>
            </form>
        </div>
    </div>

    <div class="card" id="subjectListCard">
        <div class="card-header" onclick="toggleCard('subjectListCard')">
            <h2 class="card-title">📚 Danh sách môn học</h2>
            <span class="expand-icon">▼</span>
        </div>
        <div class="card-content">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th style="width: 80px;">ID</th>
                            <th>Tên môn học</th>
                            <th style="width: 120px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($sub=$subjects->fetch_assoc()): ?>
                        <tr>
                            <td><strong>#<?= $sub['id'] ?></strong></td>
                            <td>
                                <a href="?subject_id=<?= $sub['id'] ?>" class="subject-link">
                                    <?= htmlspecialchars($sub['name']) ?>
                                </a>
                            </td>
                            <td>
                                <a href="?delete_subject=<?= $sub['id'] ?>" 
                                   class="btn btn-danger" 
                                   onclick="return confirm('Xóa môn này sẽ xóa cả câu hỏi, chắc không?')">
                                   🗑️ Xóa
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php if($current_subject): ?>
    <div class="card active" id="questionCard">
        <div class="card-header" onclick="toggleCard('questionCard')">
            <h2 class="card-title">📝 Câu hỏi môn: <?= htmlspecialchars($current_subject['name']) ?></h2>
            <span class="expand-icon">▼</span>
        </div>
        <div class="card-content">
            <div class="alert alert-info">
                <strong>Hướng dẫn:</strong> Điền đầy đủ thông tin câu hỏi và các đáp án, sau đó chọn đáp án đúng.
            </div>

            <form method="post">
                <input type="hidden" name="subject_id" value="<?= $current_subject['id'] ?>">
                
                <div class="form-group">
                    <textarea name="question" placeholder="Nhập nội dung câu hỏi..." required class="form-control"></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                    <input type="text" name="option_a" placeholder="A. Đáp án A" required class="form-control">
                    <input type="text" name="option_b" placeholder="B. Đáp án B" required class="form-control">
                    <input type="text" name="option_c" placeholder="C. Đáp án C" required class="form-control">
                    <input type="text" name="option_d" placeholder="D. Đáp án D" required class="form-control">
                </div>
                
                <div class="form-group">
                    <select name="correct_answer" required class="form-control" style="width: 200px;">
                        <option value="">-- Chọn đáp án đúng --</option>
                        <option value="A">A. Đáp án A</option>
                        <option value="B">B. Đáp án B</option>
                        <option value="C">C. Đáp án C</option>
                        <option value="D">D. Đáp án D</option>
                    </select>
                </div>
                
                <button type="submit" name="add_question" class="btn btn-primary">✅ Thêm câu hỏi</button>
            </form>

            <div style="margin: 25px 0;">
                <button type="button" onclick="toggleTable()" class="btn btn-toggle">📋 Hiển thị/Ẩn danh sách câu hỏi</button>
            </div>

            <div class="table-container" style="margin-top: 25px;">
                <table id="questionTable" style="display: none;">
                    <thead>
                        <tr>
                            <th style="width: 60px;">ID</th>
                            <th>Câu hỏi</th>
                            <th>Các đáp án</th>
                            <th style="width: 80px;">Đáp án đúng</th>
                            <th style="width: 250px;">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($q=$questions->fetch_assoc()): ?>
                        <tr>
                            <td><strong>#<?= $q['id'] ?></strong></td>
                            <td class="question-content"><?= htmlspecialchars($q['question']) ?></td>
                            <td class="options">
                                <div><strong>A</strong> <?= htmlspecialchars($q['option_a']) ?></div>
                                <div><strong>B</strong> <?= htmlspecialchars($q['option_b']) ?></div>
                                <div><strong>C</strong> <?= htmlspecialchars($q['option_c']) ?></div>
                                <div><strong>D</strong> <?= htmlspecialchars($q['option_d']) ?></div>
                            </td>
                            <td><span class="correct-answer"><?= $q['correct_answer'] ?></span></td>
                            <td class="question-actions">
                                <form method="post" class="edit-form">
                                    <input type="hidden" name="id" value="<?= $q['id'] ?>">
                                    <input type="hidden" name="subject_id" value="<?= $current_subject['id'] ?>">
                                    <textarea name="question" required class="form-control"><?= htmlspecialchars($q['question']) ?></textarea>
                                    <input type="text" name="option_a" value="<?= htmlspecialchars($q['option_a']) ?>" required class="form-control">
                                    <input type="text" name="option_b" value="<?= htmlspecialchars($q['option_b']) ?>" required class="form-control">
                                    <input type="text" name="option_c" value="<?= htmlspecialchars($q['option_c']) ?>" required class="form-control">
                                    <input type="text" name="option_d" value="<?= htmlspecialchars($q['option_d']) ?>" required class="form-control">
                                    <select name="correct_answer" required class="form-control">
                                        <option value="A" <?= $q['correct_answer']=='A'?'selected':'' ?>>A</option>
                                        <option value="B" <?= $q['correct_answer']=='B'?'selected':'' ?>>B</option>
                                        <option value="C" <?= $q['correct_answer']=='C'?'selected':'' ?>>C</option>
                                        <option value="D" <?= $q['correct_answer']=='D'?'selected':'' ?>>D</option>
                                    </select>
                                    <button type="submit" name="update_question" class="btn btn-primary">💾 Cập nhật</button>
                                </form>
                                <a href="?delete_question=<?= $q['id'] ?>&subject_id=<?= $current_subject['id'] ?>" 
                                   class="btn btn-danger" 
                                   onclick="return confirm('Xóa câu hỏi này?')">
                                   🗑️ Xóa câu hỏi
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

</body>
</html>