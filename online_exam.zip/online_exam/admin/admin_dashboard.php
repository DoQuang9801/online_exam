<?php 
session_start(); 
require "../connect/db.php"; // file db.php trong thư mục connect

// Kiểm tra session admin
if(!isset($_SESSION['admin'])){
    header("Location: ../index.php"); // nếu chưa login quay về index
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title> Trang Admin </title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
        }
        
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
            color: white;
            height: 100vh;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            z-index: 1000;
        }
        
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            padding: 0 20px;
            font-size: 24px;
            color: #ecf0f1;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        .sidebar a {
            display: block;
            color: #ecf0f1;
            padding: 15px 20px;
            text-decoration: none;
            margin: 5px 15px;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-size: 16px;
            font-weight: 500;
            position: relative;
            overflow: hidden;
        }
        
        .sidebar a::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            transition: left 0.5s ease;
        }
        
        .sidebar a:hover {
            background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.4);
        }
        
        .sidebar a:hover::before {
            left: 100%;
        }
        
        .sidebar a.logout {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%) !important;
            margin-top: 20px;
            font-weight: bold;
        }
        
        .sidebar a.logout:hover {
            background: linear-gradient(135deg, #c0392b 0%, #a93226 100%) !important;
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.4);
        }
        
        .content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(10px);
            min-height: 100vh;
        }
        
        h2 {
            color: white;
            font-size: 32px;
            margin-bottom: 30px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
            animation: fadeInDown 0.8s ease;
        }
        
        .card {
            background: linear-gradient(145deg, rgba(255,255,255,0.95), rgba(255,255,255,0.85));
            padding: 25px;
            margin: 20px 0;
            border-radius: 20px;
            box-shadow: 
                0 8px 32px rgba(0,0,0,0.1),
                inset 0 1px 0 rgba(255,255,255,0.5);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.2);
            font-size: 16px;
            line-height: 1.6;
            color: #2c3e50;
            transition: all 0.3s ease;
            animation: fadeInUp 0.8s ease;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 
                0 12px 40px rgba(0,0,0,0.15),
                inset 0 1px 0 rgba(255,255,255,0.6);
        }
        
        /* Animations */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .content {
                margin-left: 0;
                padding: 20px;
            }
            
            body {
                flex-direction: column;
            }
        }
        
        /* Scrollbar styling */
        ::-webkit-scrollbar {
            width: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.1);
        }
        
        ::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.3);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.5);
        }
        
        /* Floating particles effect */
        .content::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.3) 0%, transparent 50%);
            animation: float 20s ease-in-out infinite;
            z-index: -1;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <h2>✨ Trang Admin</h2>
        <a href="?page=dashboard">📊 Trang Chủ</a>
        <a href="add_student.php">👩‍🎓 Quản lý sinh viên</a>
        <a href="manage_questions.php">❓ Quản lý câu hỏi</a>
        <a href="manage_exams.php">📝 Quản lý kỳ thi</a>
        <a href="?page=ketqua">📑 Kết quả thi</a>
        <a href="logout.php?from=dashboard" class="logout">🚪 Đăng xuất</a>
    </div>
    
    <!-- Content -->
    <div class="content">
        <?php
        $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';
        switch ($page) {   
            default:
                echo "<h2>📊 Trang Admin</h2>
               <div class='card'>🎯 Chào mừng đến với hệ thống quản lý! Tổng quan hệ thống: số sinh viên, số kỳ thi, số câu hỏi. Theo dõi hoạt động và thống kê tổng thể của hệ thống.</div>";
        }
        ?>
    </div>

</body>
</html>