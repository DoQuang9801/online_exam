<?php
session_start();

// Xóa session admin
unset($_SESSION['admin']);
session_destroy();

// Quay về trang index
header("Location: ../index.php");
exit();
?>
