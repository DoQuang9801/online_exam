<!-- footer.php -->
<footer>
    <p>&copy; 2025 Hệ thống Thi Trực Tuyến</p>
</footer>