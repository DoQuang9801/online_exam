<?php
function ma_hoa_mat_khau($mat_khau){
    return password_hash($mat_khau, PASSWORD_DEFAULT);
}

function kiem_tra_mat_khau($mat_khau, $hash){
    return password_verify($mat_khau, $hash);
}
?>
    