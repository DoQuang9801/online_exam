<!-- header.php -->
<header>
    <img src="../tai_nguyen/images/logo.png" alt="Logo">
    <h1>Hệ thống Thi Trực Tuyến</h1>
</header>