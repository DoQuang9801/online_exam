<?php
session_start(); // Bắt đầu session

// --- Thông tin kết nối cơ sở dữ liệu ---
define('MAY_CHU', 'localhost');      // Máy chủ MySQL
define('TEN_NGUOI_DUNG', 'root');    // Tài khoản MySQL
define('MAT_KHAU', '');              // Mật khẩu MySQL
define('CSDL', 'thi_truc_tuyen');    // Tên database

// --- Kết nối CSDL ---
$conn = new mysqli(MAY_CHU, TEN_NGUOI_DUNG, MAT_KHAU, CSDL);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối cơ sở dữ liệu thất bại: " . $conn->connect_error);
}

// --- Hàm mã hóa mật khẩu ---
function ma_hoa_mat_khau($mat_khau) {
    return password_hash($mat_khau, PASSWORD_BCRYPT);
}

// --- Kiểm tra đăng nhập Admin ---
function dang_nhap_admin() {
    return isset($_SESSION['admin_id']);
}

// --- Bắt buộc đăng nhập Admin ---
function yeu_cau_admin_dang_nhap() {
    if (!dang_nhap_admin()) {
        header("Location: index.php");
        exit();
    }
}
?>
