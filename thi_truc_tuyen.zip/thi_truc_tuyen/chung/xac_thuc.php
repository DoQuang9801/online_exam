<?php
session_start();

// Nếu chưa đăng nhập
if(!isset($_SESSION['taikhoan'])){
    header("Location: index.php");
    exit();
}

// Kiểm tra quyền Admin nếu cần
if(isset($admin_only) && $admin_only === true){
    if($_SESSION['quyen'] != 'superadmin' && $_SESSION['quyen'] != 'moderator'){
        echo "Bạn không có quyền truy cập trang này!";
        exit();
    }
}
?>
