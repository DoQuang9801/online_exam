<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Web Thi Online</title>
<link rel="stylesheet" href="tai_nguyen/css/style.css">
<style>
body { font-family: Arial; background: #f0f0f0; text-align:center; }
.container { margin-top: 100px; }
.btn { display:inline-block; padding:15px 30px; margin:20px; font-size:18px; color:white; background:#3498db; text-decoration:none; border-radius:10px; transition:0.3s; }
.btn:hover { background:#2980b9; transform:scale(1.1); }
</style>
</head><!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Web Thi Online</title>
<link rel="stylesheet" href="tai_nguyen/css/style.css">
<style>
body { font-family: Arial; background: #f0f0f0; text-align:center; }
.container { margin-top: 100px; }
.btn { display:inline-block; padding:15px 30px; margin:20px; font-size:18px; color:white; background:#3498db; text-decoration:none; border-radius:10px; transition:0.3s; }
.btn:hover { background:#2980b9; transform:scale(1.1); }
</style>
</head>
<body>
<div class="container">
<h1>Chào mừng đến Web Thi Online</h1>
<p>Vui lòng chọn loại tài khoản để đăng nhập:</p>
<a href="admin/index.php" class="btn">Admin</a>
<a href="thi_sinh/index.php" class="btn">Thí sinh</a>
</div>
</body>
</html>