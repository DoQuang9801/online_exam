<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Bảng xếp hạng</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Bảng xếp hạng</h2>
<?php
$sql="SELECT u.taikhoan, SUM(ke.diem) as tong_diem 
FROM ket_qua ke
JOIN users u ON ke.id_user=u.id
GROUP BY u.id ORDER BY tong_diem DESC";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>Thí sinh</th><th>Tổng điểm</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['taikhoan']."</td><td>".$row['tong_diem']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có thí sinh nào.</p>";
}
?>
<p><a href="index.php">Quay lại trang chủ</a></p>
</div>
</body>
</html>
