<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
$id_user=$_SESSION['user_id'];
$sql="SELECT k.ten_ky_thi, ke.diem, ke.ngay_lam 
FROM ket_qua ke
JOIN ky_thi k ON ke.id_ky_thi=k.id
WHERE ke.id_user=?";
$stmt=$conn->prepare($sql);
$stmt->bind_param("i",$id_user);
$stmt->execute();
$result=$stmt->get_result();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Lịch sử thi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Lịch sử thi của bạn</h2>
<?php
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>Kỳ thi</th><th>Điểm</th><th>Ngày làm</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['ten_ky_thi']."</td><td>".$row['diem']."</td><td>".$row['ngay_lam']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Bạn chưa tham gia kỳ thi nào.</p>";
}
?>
<p><a href="index.php">Quay về trang chủ</a></p>
</div>
</body>
</html>
