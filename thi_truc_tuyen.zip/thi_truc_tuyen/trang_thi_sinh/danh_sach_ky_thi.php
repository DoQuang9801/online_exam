<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Danh sách kỳ thi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Danh sách kỳ thi</h2>
<?php
$sql="SELECT * FROM ky_thi";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<ul>";
    while($row=$result->fetch_assoc()){
        echo "<li>".$row['ten_ky_thi']." (".$row['ngay_bat_dau']." - ".$row['ngay_ket_thuc'].") <a href='lam_bai_thi.php?id=".$row['id']."'>Làm bài</a></li>";
    }
    echo "</ul>";
}else{
    echo "<p>Chưa có kỳ thi nào.</p>";
}
?>
<p><a href="index.php">Quay về trang chủ</a></p>
</div>
</body>
</html>
