<?php
session_start();
include '../chung/ket_noi_db.php';
include '../chung/ham_chung.php';
$thongbao='';
if(isset($_POST['taikhoan'],$_POST['mat_khau'])){
    $taikhoan=trim($_POST['taikhoan']);
    $mat_khau=$_POST['mat_khau'];
    $sql="SELECT * FROM users WHERE taikhoan=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s",$taikhoan);
    $stmt->execute();
    $result=$stmt->get_result();
    if($result->num_rows>0){$thongbao="Tài khoản đã tồn tại!";}
    else{
        $mat_khau_hash=ma_hoa_mat_khau($mat_khau);
        $sql="INSERT INTO users (taikhoan, mat_khau) VALUES (?,?)";
        $stmt=$conn->prepare($sql);
        $stmt->bind_param("ss",$taikhoan,$mat_khau_hash);
        $stmt->execute();
        header("refresh:2; url=index.php");
        $thongbao="Đăng ký thành công! Chuyển về trang đăng nhập...";
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng ký Thí sinh</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<header><img src="../tai_nguyen/images/logo.png"><h1>Đăng ký Thí sinh</h1></header>
<?php if($thongbao!='') echo "<p style='color:red;text-align:center;'>$thongbao</p>";?>
<form method="POST" action="">
<input type="text" name="taikhoan" placeholder="Tên tài khoản" required>
<input type="password" name="mat_khau" placeholder="Mật khẩu" required>
<button type="submit">Đăng ký</button>
</form>
<p style="text-align:center;margin-top:10px;">Đã có tài khoản? <a href="index.php">Đăng nhập</a></p>
</div>
</body>
</html>
