<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';

$id_user=$_SESSION['user_id'];
$id_ky_thi=$_POST['id_ky_thi']??0;

// Lấy danh sách câu hỏi
$sql="SELECT * FROM cau_hoi WHERE id_ky_thi=?";
$stmt=$conn->prepare($sql);
$stmt->bind_param("i",$id_ky_thi);
$stmt->execute();
$result=$stmt->get_result();

$diem=0;
while($row=$result->fetch_assoc()){
    $cau_id=$row['id'];
    $dap_an=$_POST['cau_'.$cau_id]??'';
    if($dap_an==$row['dap_an_dung']) $diem+=1;
}

// Lưu kết quả
$sql="INSERT INTO ket_qua (id_user,id_ky_thi,diem,ngay_lam) VALUES (?,?,?,NOW())";
$stmt=$conn->prepare($sql);
$stmt->bind_param("iid",$id_user,$id_ky_thi,$diem);
$stmt->execute();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Kết quả</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Kết quả bài thi</h2>
<p>Bạn đạt: <?php echo $diem; ?> điểm</p>
<p><a href="danh_sach_ky_thi.php">Quay lại danh sách kỳ thi</a></p>
</div>
</body>
</html>
