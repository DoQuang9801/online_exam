<?php
session_start();
include '../chung/ket_noi_db.php';
include '../chung/ham_chung.php';
$thongbao='';
if(isset($_POST['taikhoan'],$_POST['mat_khau'])){
    $taikhoan=$_POST['taikhoan'];
    $mat_khau=$_POST['mat_khau'];
    $sql="SELECT * FROM users WHERE taikhoan=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s",$taikhoan);
    $stmt->execute();
    $result=$stmt->get_result();
    if($row=$result->fetch_assoc()){
        if(kiem_tra_mat_khau($mat_khau,$row['mat_khau'])){
            $_SESSION['user_id']=$row['id'];
            $_SESSION['taikhoan']=$row['taikhoan'];
            header("Location:danh_sach_ky_thi.php"); exit();
        }else{$thongbao="Mật khẩu không đúng!";}
    }else{$thongbao="Tài khoản không tồn tại!";}
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập Thí sinh</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<header><img src="../tai_nguyen/images/logo.png"><h1>Đăng nhập Thí sinh</h1></header>
<?php if($thongbao!='') echo "<p style='color:red;text-align:center;'>$thongbao</p>";?>
<form method="POST" action="">
<input type="text" name="taikhoan" placeholder="Tên tài khoản" required>
<input type="password" name="mat_khau" placeholder="Mật khẩu" required>
<button type="submit">Đăng nhập</button>
</form>
<p style="text-align:center;margin-top:10px;">Chưa có tài khoản? <a href="dang_ky.php">Đăng ký</a></p>
</div>
</body>
</html>
