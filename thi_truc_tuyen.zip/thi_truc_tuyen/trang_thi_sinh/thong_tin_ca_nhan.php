<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
$id_user=$_SESSION['user_id'];

$thongbao='';
if(isset($_POST['ho_ten'])){
    $ho_ten=$_POST['ho_ten'];
    $sql="UPDATE users SET ho_ten=? WHERE id=?";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("si",$ho_ten,$id_user);
    $stmt->execute();
    $thongbao="Cập nhật thông tin thành công!";
}

$sql="SELECT * FROM users WHERE id=?";
$stmt=$conn->prepare($sql);
$stmt->bind_param("i",$id_user);
$stmt->execute();
$result=$stmt->get_result();
$row=$result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thông tin cá nhân</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Thông tin cá nhân</h2>
<?php if($thongbao!='') echo "<p style='color:green;'>$thongbao</p>"; ?>
<form method="POST">
<p>Tài khoản: <?php echo $row['taikhoan']; ?></p>
<input type="text" name="ho_ten" value="<?php echo $row['ho_ten']; ?>" placeholder="Họ tên">
<button type="submit">Cập nhật</button>
</form>
<p><a href="index.php">Quay lại trang chủ</a></p>
</div>
</body>
</html>
