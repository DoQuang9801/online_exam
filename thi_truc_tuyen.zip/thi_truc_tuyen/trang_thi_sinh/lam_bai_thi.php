<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';

$id_ky_thi=$_GET['id']??0;
$sql="SELECT * FROM cau_hoi WHERE id_ky_thi=?";
$stmt=$conn->prepare($sql);
$stmt->bind_param("i",$id_ky_thi);
$stmt->execute();
$result=$stmt->get_result();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Làm bài thi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Bài thi</h2>
<form method="POST" action="ket_qua.php">
<?php
if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        echo "<p>".$row['cau_hoi']."</p>";
        echo "<input type='radio' name='cau_".$row['id']."' value='A'>".$row['dap_an_a']."<br>";
        echo "<input type='radio' name='cau_".$row['id']."' value='B'>".$row['dap_an_b']."<br>";
        echo "<input type='radio' name='cau_".$row['id']."' value='C'>".$row['dap_an_c']."<br>";
        echo "<input type='radio' name='cau_".$row['id']."' value='D'>".$row['dap_an_d']."<br><hr>";
    }
}else{
    echo "<p>Chưa có câu hỏi cho kỳ thi này.</p>";
}
?>
<input type="hidden" name="id_ky_thi" value="<?php echo $id_ky_thi; ?>">
<button type="submit">Nộp bài</button>
</form>
</div>
<script src="../tai_nguyen/js/chong_gian_lan.js"></script>
</body>
</html>
