<?php
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thi thử</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Thi thử</h2>
<p>Chọn kỳ thi thử:</p>
<ul>
<?php
$sql="SELECT * FROM ky_thi";
$result=$conn->query($sql);
if($result->num_rows>0){
    while($row=$result->fetch_assoc()){
        echo "<li>".$row['ten_ky_thi']." <a href='lam_bai_thi.php?id=".$row['id']."'>Làm bài thử</a></li>";
    }
}else{
    echo "<p>Chưa có kỳ thi thử nào.</p>";
}
?>
</ul>
<p><a href="index.php">Quay lại trang chủ</a></p>
</div>
</body>
</html>
