-- 1. Tạo database
CREATE DATABASE IF NOT EXISTS thi_truc_tuyen CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE thi_truc_tuyen;

-- 2. Bảng Admin
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    taikhoan VARCHAR(50) UNIQUE NOT NULL,
    mat_khau VARCHAR(255) NOT NULL,
    quyen ENUM('superadmin','moderator') DEFAULT 'moderator'
);

-- Thêm admin mặc định: tài khoản: admin, mật khẩu: admin123
INSERT INTO admins (taikhoan, mat_khau, quyen) VALUES 
('admin', '$2y$10$E9D2nHZmBkzjAuo0Sj7F8ebG.ZYdQFzU1t3ZfPik/0QH7DpZ6Z4Ai', 'superadmin'); 
-- Mật khẩu đã hash bằng bcrypt: admin123

-- 3. Bảng Thí sinh (users)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    taikhoan VARCHAR(50) UNIQUE NOT NULL,
    mat_khau VARCHAR(255) NOT NULL,
    ho_ten VARCHAR(100) DEFAULT NULL
);

-- 4. Bảng Kỳ thi
CREATE TABLE IF NOT EXISTS ky_thi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ten_ky_thi VARCHAR(100) NOT NULL,
    ngay_bat_dau DATE,
    ngay_ket_thuc DATE
);

-- 5. Bảng Câu hỏi
CREATE TABLE IF NOT EXISTS cau_hoi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_ky_thi INT NOT NULL,
    cau_hoi TEXT NOT NULL,
    dap_an_a VARCHAR(255) NOT NULL,
    dap_an_b VARCHAR(255) NOT NULL,
    dap_an_c VARCHAR(255) NOT NULL,
    dap_an_d VARCHAR(255) NOT NULL,
    dap_an_dung ENUM('A','B','C','D') NOT NULL,
    FOREIGN KEY (id_ky_thi) REFERENCES ky_thi(id) ON DELETE CASCADE
);

-- 6. Bảng Kết quả
CREATE TABLE IF NOT EXISTS ket_qua (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT NOT NULL,
    id_ky_thi INT NOT NULL,
    diem FLOAT DEFAULT 0,
    ngay_lam DATETIME,
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (id_ky_thi) REFERENCES ky_thi(id) ON DELETE CASCADE
);

-- 7. Bảng Thông báo
CREATE TABLE IF NOT EXISTS thong_bao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    noi_dung TEXT NOT NULL,
    ngay_gui DATETIME DEFAULT CURRENT_TIMESTAMP
);
