<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý kỳ thi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Quản lý kỳ thi</h2>
<?php
$sql="SELECT * FROM ky_thi";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Tên kỳ thi</th><th>Ngày bắt đầu</th><th>Ngày kết thúc</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['id']."</td><td>".$row['ten_ky_thi']."</td><td>".$row['ngay_bat_dau']."</td><td>".$row['ngay_ket_thuc']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có kỳ thi nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
