<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include '../config.php';

$thong_bao = '';

if(isset($_POST['taikhoan']) && isset($_POST['mat_khau'])){
    $taikhoan = $_POST['taikhoan'];
    $mat_khau = $_POST['mat_khau'];

    $sql = "SELECT * FROM admins WHERE taikhoan = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $taikhoan);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 1){
        $admin = $result->fetch_assoc();
        if(password_verify($mat_khau, $admin['mat_khau'])){
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_taikhoan'] = $admin['taikhoan'];
            header("Location: dashboard.php");
            exit();
        } else {
            $thong_bao = "Mật khẩu không đúng!";
        }
    } else {
        $thong_bao = "Tài khoản không tồn tại!";
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Đăng nhập Admin</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
<style>
body { font-family: Arial; background: #f0f0f0; text-align:center; }
.container { margin-top: 100px; display:inline-block; padding:40px; background:white; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2); }
input { display:block; margin:15px auto; padding:10px; width:80%; font-size:16px; }
button { padding:10px 20px; font-size:16px; background:#3498db; color:white; border:none; border-radius:5px; cursor:pointer; transition:0.3s; }
button:hover { background:#2980b9; transform:scale(1.05); }
p.thongbao { color:red; font-weight:bold; }
</style>
</head>
<body>
<div class="container">
<h2>Đăng nhập Admin</h2>
<?php if($thong_bao != '') echo "<p class='thongbao'>$thong_bao</p>"; ?>
<form method="POST">
<input type="text" name="taikhoan" placeholder="Tài khoản" required>
<input type="password" name="mat_khau" placeholder="Mật khẩu" required>
<button type="submit">Đăng nhập</button>
</form>
</div>
</body>
</html>
