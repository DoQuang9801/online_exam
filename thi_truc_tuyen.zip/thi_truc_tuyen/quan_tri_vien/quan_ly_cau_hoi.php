<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý câu hỏi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Quản lý câu hỏi</h2>
<?php
$sql="SELECT c.id, k.ten_ky_thi, c.cau_hoi, c.dap_an_dung FROM cau_hoi c JOIN ky_thi k ON c.id_ky_thi=k.id";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Kỳ thi</th><th>Câu hỏi</th><th>Đáp án đúng</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['id']."</td><td>".$row['ten_ky_thi']."</td><td>".$row['cau_hoi']."</td><td>".$row['dap_an_dung']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có câu hỏi nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
