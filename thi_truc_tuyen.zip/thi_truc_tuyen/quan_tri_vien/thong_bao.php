<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';

if(isset($_POST['noi_dung'])){
    $noi_dung=$_POST['noi_dung'];
    $sql="INSERT INTO thong_bao(noi_dung,ngay_gui) VALUES (?,NOW())";
    $stmt=$conn->prepare($sql);
    $stmt->bind_param("s",$noi_dung);
    $stmt->execute();
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thông báo</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Gửi thông báo</h2>
<form method="POST">
<textarea name="noi_dung" placeholder="Nhập nội dung thông báo" required></textarea><br>
<button type="submit">Gửi thông báo</button>
</form>
<?php
$sql="SELECT * FROM thong_bao ORDER BY ngay_gui DESC";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<ul>";
    while($row=$result->fetch_assoc()){
        echo "<li>".$row['ngay_gui'].": ".$row['noi_dung']."</li>";
    }
    echo "</ul>";
}else{
    echo "<p>Chưa có thông báo nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
