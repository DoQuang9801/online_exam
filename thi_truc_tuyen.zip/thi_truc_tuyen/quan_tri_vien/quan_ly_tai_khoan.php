<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý tài khoản</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Quản lý tài khoản thí sinh</h2>

<?php
$sql="SELECT * FROM users";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Tài khoản</th><th>Họ tên</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['id']."</td><td>".$row['taikhoan']."</td><td>".$row['ho_ten']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có thí sinh nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
