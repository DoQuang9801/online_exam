<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chấm bài tự luận</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Chấm bài tự luận</h2>
<?php
$sql="SELECT ke.id as ketqua_id, u.taikhoan, k.ten_ky_thi, ke.diem 
FROM ket_qua ke 
JOIN users u ON ke.id_user=u.id
JOIN ky_thi k ON ke.id_ky_thi=k.id";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>ID</th><th>Thí sinh</th><th>Kỳ thi</th><th>Điểm</th><th>Thao tác</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr>
                <td>".$row['ketqua_id']."</td>
                <td>".$row['taikhoan']."</td>
                <td>".$row['ten_ky_thi']."</td>
                <td>".$row['diem']."</td>
                <td><a href='sua_diem.php?id=".$row['ketqua_id']."'>Chấm sửa</a></td>
              </tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có bài tự luận nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
