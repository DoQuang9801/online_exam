<?php
$admin_only=true;
include '../chung/xac_thuc.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Dashboard Admin</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<?php include 'header.php'; ?>
<h2>Chào, <?php echo $_SESSION['taikhoan']; ?></h2>
<ul>
<li><a href="quan_ly_tai_khoan.php">Quản lý tài khoản</a></li>
<li><a href="quan_ly_ky_thi.php">Quản lý kỳ thi</a></li>
<li><a href="quan_ly_cau_hoi.php">Quản lý câu hỏi</a></li>
<li><a href="bao_cao.php">Báo cáo</a></li>
<li><a href="dang_xuat.php">Đăng xuất</a></li>
</ul>
<?php include 'footer.php'; ?>
</div>
</body>
</html>
