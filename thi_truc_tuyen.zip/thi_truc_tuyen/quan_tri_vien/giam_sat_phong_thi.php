<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Giám sát phòng thi</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Giám sát phòng thi</h2>
<?php
$sql="SELECT u.taikhoan, k.ten_ky_thi, ke.ngay_lam 
FROM ket_qua ke
JOIN users u ON ke.id_user=u.id
JOIN ky_thi k ON ke.id_ky_thi=k.id
ORDER BY ke.ngay_lam DESC";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>Thí sinh</th><th>Kỳ thi</th><th>Ngày làm</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['taikhoan']."</td><td>".$row['ten_ky_thi']."</td><td>".$row['ngay_lam']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có thí sinh nào làm bài.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
