<?php
$admin_only=true;
include '../chung/xac_thuc.php';
include '../chung/ket_noi_db.php';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Báo cáo</title>
<link rel="stylesheet" href="../tai_nguyen/css/style.css">
</head>
<body>
<div class="container">
<h2>Báo cáo kết quả</h2>
<?php
$sql="SELECT k.ten_ky_thi, u.taikhoan, ke.diem, ke.ngay_lam 
FROM ket_qua ke 
JOIN users u ON ke.id_user=u.id 
JOIN ky_thi k ON ke.id_ky_thi=k.id";
$result=$conn->query($sql);
if($result->num_rows>0){
    echo "<table border='1' width='100%' style='border-collapse:collapse;'>";
    echo "<tr><th>Kỳ thi</th><th>Tài khoản</th><th>Điểm</th><th>Ngày làm</th></tr>";
    while($row=$result->fetch_assoc()){
        echo "<tr><td>".$row['ten_ky_thi']."</td><td>".$row['taikhoan']."</td><td>".$row['diem']."</td><td>".$row['ngay_lam']."</td></tr>";
    }
    echo "</table>";
}else{
    echo "<p>Chưa có kết quả nào.</p>";
}
?>
<p><a href="bang_dieu_khien.php">Quay về Dashboard</a></p>
</div>
</body>
</html>
