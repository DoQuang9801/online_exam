// Ngăn người dùng copy/paste, inspect, F12
document.addEventListener('contextmenu', event => event.preventDefault());
document.addEventListener('keydown', function(e) {
    // F12, Ctrl+Shift+I, Ctrl+U, Ctrl+C
    if(e.keyCode==123 || 
       (e.ctrlKey && e.shiftKey && e.keyCode==73) || 
       (e.ctrlKey && e.keyCode==85) || 
       (e.ctrlKey && e.keyCode==67)){
        alert("Tính năng bị vô hiệu hóa!");
        e.preventDefault();
    }
});

// Ngăn di chuyển tab ra ngoài
window.addEventListener("blur", function(){
    alert("Không được rời khỏi trang thi!");
});
